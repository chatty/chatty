/*
* Copyright (c) 2002 and later by MH Software-Entwicklung. All Rights Reserved.
*  
* JTattoo is multiple licensed. If your are an open source developer you can use
* it under the terms and conditions of the GNU General Public License version 2.0
* or later as published by the Free Software Foundation.
*  
* see: gpl-2.0.txt
* 
* If you pay for a license you will become a registered user who could use the
* software under the terms and conditions of the GNU Lesser General Public License
* version 2.0 or later with classpath exception as published by the Free Software
* Foundation.
* 
* see: lgpl-2.0.txt
* see: classpath-exception.txt
* 
* Registered users could also use JTattoo under the terms and conditions of the 
* Apache License, Version 2.0 as published by the Apache Software Foundation.
*  
* see: APACHE-LICENSE-2.0.txt
 */
package com.jtattoo.plaf.hifi;

import com.jtattoo.plaf.*;
import java.awt.*;
import javax.swing.JComponent;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.UIResource;
import javax.swing.text.View;

/**
 * @author Michael Hagen
 */
public class HiFiTabbedPaneUI extends BaseTabbedPaneUI {

    public static ComponentUI createUI(JComponent c) {
        return new HiFiTabbedPaneUI();
    }
    
    @Override
    public void installDefaults() {
        super.installDefaults();
        switch (AbstractLookAndFeel.getTheme().getTabSeparatorStyle()) {
            case 2:
                tabAreaInsets.bottom = 0;
                break;
            case 3:
                tabAreaInsets.bottom = 2;
                break;
            case 4:
            case 5:
                tabAreaInsets.bottom = 4;
                break;
            default:
                tabAreaInsets.bottom = 5;
        }
    }

    @Override
    protected Color[] getContentBorderColors(int tabPlacement) {
        Color selColor = AbstractLookAndFeel.getTheme().getSelectionBackgroundColorDark();
        Color bgColor = AbstractLookAndFeel.getBackgroundColor();
        switch (AbstractLookAndFeel.getTheme().getTabSeparatorStyle()) {
            // Almost default
            case 1:
                return new Color[]{
                    ColorHelper.darker(AbstractLookAndFeel.getBackgroundColor(), 40),
                    ColorHelper.brighter(AbstractLookAndFeel.getBackgroundColor(), 10),
                    ColorHelper.darker(AbstractLookAndFeel.getBackgroundColor(), 20),
                    ColorHelper.darker(AbstractLookAndFeel.getBackgroundColor(), 40),
                    ColorHelper.darker(AbstractLookAndFeel.getBackgroundColor(), 60),};
            case 3:
                return new Color[]{
                    ColorHelper.darker(AbstractLookAndFeel.getBackgroundColor(), 40),
                    ColorHelper.darker(AbstractLookAndFeel.getBackgroundColor(), 40),
                };
            // Size 4
            case 4:
                return new Color[]{
                    ColorHelper.darker(AbstractLookAndFeel.getBackgroundColor(), 40),
                    ColorHelper.darker(AbstractLookAndFeel.getBackgroundColor(), 10),
                    ColorHelper.darker(AbstractLookAndFeel.getBackgroundColor(), 30),
                    ColorHelper.darker(AbstractLookAndFeel.getBackgroundColor(), 50),};
            
            case 5:
                return new Color[]{
                    ColorHelper.darker(selColor, 50),
                    ColorHelper.darker(selColor, 0),
                    ColorHelper.darker(selColor, 30),
                    ColorHelper.darker(selColor, 60),};
            // Size 5
            case 6:
                return new Color[]{
                    ColorHelper.darker(selColor, 50),
                    ColorHelper.darker(selColor, 0),
                    ColorHelper.darker(selColor, 20),
                    ColorHelper.darker(selColor, 40),
                    ColorHelper.darker(selColor, 60)};
            case 7:
                return new Color[]{
                    ColorHelper.darker(ColorHelper.median(bgColor, selColor), 50),
                    ColorHelper.darker(ColorHelper.median(bgColor, selColor), 0),
                    ColorHelper.darker(ColorHelper.median(bgColor, selColor), 20),
                    ColorHelper.darker(ColorHelper.median(bgColor, selColor), 40),
                    ColorHelper.darker(ColorHelper.median(bgColor, selColor), 60)};
            case 8:
                return new Color[]{
                    ColorHelper.darker(ColorHelper.median(bgColor, selColor), 50),
                    ColorHelper.darker(ColorHelper.median(bgColor, selColor), 0),
                    ColorHelper.darker(ColorHelper.median(bgColor, selColor), 5),
                    ColorHelper.darker(ColorHelper.median(bgColor, selColor), 20),
                    ColorHelper.darker(ColorHelper.median(bgColor, selColor), 60)};
            default:
                return new Color[]{
                    ColorHelper.darker(AbstractLookAndFeel.getBackgroundColor(), 40),
                    ColorHelper.brighter(AbstractLookAndFeel.getBackgroundColor(), 20),
                    ColorHelper.darker(AbstractLookAndFeel.getBackgroundColor(), 20),
                    ColorHelper.darker(AbstractLookAndFeel.getBackgroundColor(), 40),
                    ColorHelper.darker(AbstractLookAndFeel.getBackgroundColor(), 60),};
        }
    }

    @Override
    protected void paintText(Graphics g, int tabPlacement, Font font, FontMetrics metrics, int tabIndex, String title, Rectangle textRect, boolean isSelected) {
        Color backColor = tabPane.getBackgroundAt(tabIndex);
        if (!(backColor instanceof UIResource)) {
            super.paintText(g, tabPlacement, font, metrics, tabIndex, title, textRect, isSelected);
            return;
        }
        g.setFont(font);
        View v = getTextViewForTab(tabIndex);
        if (v != null) {
            // html
            Graphics2D g2D = (Graphics2D) g;
            Object savedRenderingHint = null;
            if (AbstractLookAndFeel.getTheme().isTextAntiAliasingOn()) {
                savedRenderingHint = g2D.getRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING);
                g2D.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, AbstractLookAndFeel.getTheme().getTextAntiAliasingHint());
            }
            v.paint(g, textRect);
            if (AbstractLookAndFeel.getTheme().isTextAntiAliasingOn()) {
                g2D.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, savedRenderingHint);
            }
        } else {
            // plain text
            int mnemIndex = tabPane.getDisplayedMnemonicIndexAt(tabIndex);

            Graphics2D g2D = (Graphics2D) g;
            
            Color fc = tabPane.getForegroundAt(tabIndex);
            if (isSelected) {
                fc = AbstractLookAndFeel.getTheme().getTabSelectionForegroundColor();
            }
            if (!tabPane.isEnabled() || !tabPane.isEnabledAt(tabIndex)) {
                fc = AbstractLookAndFeel.getTheme().getDisabledForegroundColor();
            }
            if (ColorHelper.getGrayValue(fc) > 128) {
                g2D.setColor(Color.black);
            } else {
                g2D.setColor(Color.white);
            }
            if (AbstractLookAndFeel.getTheme().isTextShadowOn()) {
                Composite savedComposite = g2D.getComposite();
                AlphaComposite alpha = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.6f);
                g2D.setComposite(alpha);
                JTattooUtilities.drawStringUnderlineCharAt(tabPane, g, title, mnemIndex, textRect.x + 1, textRect.y + 1 + metrics.getAscent());
                g2D.setComposite(savedComposite);
            }
            g2D.setColor(fc);
            JTattooUtilities.drawStringUnderlineCharAt(tabPane, g, title, mnemIndex, textRect.x, textRect.y + metrics.getAscent());
        }
    }

} // end of class HiFiTabbedPaneUI
